/*
 * Copyright (C) 2013 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package fi.jouko.blefreezer3;

import java.nio.ByteBuffer;
import java.text.BreakIterator;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.lang.Double;
import java.io.File;
import java.text.BreakIterator;




import android.app.Activity;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.graphics.drawable.ColorDrawable;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ExpandableListView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.LegendRenderer;
import com.jjoe64.graphview.Viewport;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import static fi.jouko.blefreezer3.BluetoothLeService.EXTRA_BYTES;
/**
 * For a given BLE device, this Activity provides the user interface to connect, display data,
 * and display GATT services and characteristics supported by the device.  The Activity
 * communicates with {@code BluetoothLeService}, which in turn interacts with the
 * Bluetooth LE API.
 */
public class DeviceControlActivity extends Activity {
    private final static String TAG = DeviceControlActivity.class.getSimpleName();

    public static final String EXTRAS_DEVICE_NAME = "DEVICE_NAME";
    public static final String EXTRAS_DEVICE_ADDRESS = "DEVICE_ADDRESS";


    private TextView mConnectionState;
    private TextView mDataField;
    private TextView mBatData;
    private TextView mTempCData;
    private TextView mTempCset;
    private TextView mEnergyData;
    private ImageView mFreezerOn;
    private ImageView mInverterOn;

    private String mDeviceName;
    private String mDeviceAddress;
    private ExpandableListView mGattServicesList;
    private BluetoothLeService mBluetoothLeService;
    private ArrayList<ArrayList<BluetoothGattCharacteristic>> mGattCharacteristics =
            new ArrayList<ArrayList<BluetoothGattCharacteristic>>();
    private boolean mConnected = false;
    private BluetoothGattCharacteristic mNotifyCharacteristic;
    private LineGraphSeries<DataPoint> series;
    private LineGraphSeries<DataPoint> series2;
    private int lastX = 0;

    boolean connect_status_bit=false;
    
    private final String LIST_NAME = "NAME";
    private final String LIST_UUID = "UUID";

    private Handler mHandler;

    // Stops scanning after 10 seconds.
    private static final long SCAN_PERIOD = 10000;
    private byte freezer_set = 32;

    private int i = 0;
    private int TIME = 1000;

    ImageView freezer_state;
    ImageButton switch_inverter;
    ImageButton show_log;
    ImageButton plus;
    ImageButton minus;
    
    // Code to manage Service lifecycle.
    private final ServiceConnection mServiceConnection = new ServiceConnection() {

        @Override
        public void onServiceConnected(ComponentName componentName, IBinder service) {
            mBluetoothLeService = ((BluetoothLeService.LocalBinder) service).getService();
            if (!mBluetoothLeService.initialize()) {
                Log.e(TAG, "Unable to initialize Bluetooth");
                finish();
            }
            // Automatically connects to the device upon successful start-up initialization.
            mBluetoothLeService.connect(mDeviceAddress);
        }

        @Override
        public void onServiceDisconnected(ComponentName componentName) {
            mBluetoothLeService = null;
        }
    };

    // Handles various events fired by the Service.
    // ACTION_GATT_CONNECTED: connected to a GATT server.
    // ACTION_GATT_DISCONNECTED: disconnected from a GATT server.
    // ACTION_GATT_SERVICES_DISCOVERED: discovered GATT services.
    // ACTION_DATA_AVAILABLE: received data from the device.  This can be a result of read
    //                        or notification operations.
    private final BroadcastReceiver mGattUpdateReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            final String action = intent.getAction();
            if (BluetoothLeService.ACTION_GATT_CONNECTED.equals(action)) {
                mConnected = true;
                
                
                connect_status_bit=true;
                
                invalidateOptionsMenu();
            } else if (BluetoothLeService.ACTION_GATT_DISCONNECTED.equals(action)) {
                mConnected = false;
                
                updateConnectionState(R.string.disconnected);
                connect_status_bit=false;
                show_view(false);
                invalidateOptionsMenu();
               // clearUI();
            } else if (BluetoothLeService.ACTION_GATT_SERVICES_DISCOVERED.equals(action)) {
                // Show all the supported services and characteristics on the user interface.
                displayGattServices(mBluetoothLeService.getSupportedGattServices());
            } else if (BluetoothLeService.ACTION_DATA_AVAILABLE.equals(action)) {
                displayData(intent.getByteArrayExtra(EXTRA_BYTES));

            }
        }
    };

    // If a given GATT characteristic is selected, check for supported features.  This sample
    // demonstrates 'Read' and 'Notify' features.  See
    // http://d.android.com/reference/android/bluetooth/BluetoothGatt.html for the complete
    // list of supported characteristic features.
    private final ExpandableListView.OnChildClickListener servicesListClickListner =
            new ExpandableListView.OnChildClickListener() {
                @Override
                public boolean onChildClick(ExpandableListView parent, View v, int groupPosition,
                                            int childPosition, long id) {
                	
//                	Log.i("tag", "uu");
//                    if (mGattCharacteristics != null) {
//                        final BluetoothGattCharacteristic characteristic =
//                                mGattCharacteristics.get(groupPosition).get(childPosition);
//                        final int charaProp = characteristic.getProperties();
//                        if ((charaProp | BluetoothGattCharacteristic.PROPERTY_READ) > 0) {
//                            // If there is an active notification on a characteristic, clear
//                            // it first so it doesn't update the data field on the user interface.
//                            if (mNotifyCharacteristic != null) {
//                                mBluetoothLeService.setCharacteristicNotification(
//                                        mNotifyCharacteristic, false);
//                                mNotifyCharacteristic = null;
//                            }
//                            mBluetoothLeService.readCharacteristic(characteristic);
//                        }
//                        if ((charaProp | BluetoothGattCharacteristic.PROPERTY_NOTIFY) > 0) {
//                            mNotifyCharacteristic = characteristic;
//                            mBluetoothLeService.setCharacteristicNotification(
//                                    characteristic, true);
//                        }
//                        return true;
//                    }
                    return false;
                }
    };

    private void clearUI() {
        //mGattServicesList.setAdapter((SimpleExpandableListAdapter) null);
        mDataField.setText(R.string.no_data);
    }

    Button send_button;

    
    EditText ibeacon_uuid;
    EditText mayjor_txt,minor_txt;
    
    EditText dev_Name;
    Button name_button;
    
    EditText password_ed; //Password value
    Button password_enable_bt; //Password switch
    Button password_wrt; //Write password Button
    
    Button adv_time1,adv_time2,adv_time3,adv_time4;
    
    boolean pass_en=false;

    
    boolean keep_power = false;
    boolean inverter_on = false;
    boolean freezer_on = false;

    boolean swt4_st = false;
    
    
    private Button IO_H_button,IO_L_button;  //out io
    Timer timer = new Timer();  

//    Button id_btt;
//    Button pass_btt;
//    Button name_btt;
    
    String dme ="";
    
    void show_view( boolean p )
    {
    	if(p){
    //		send_button.setEnabled(true);
    	}else{
    //		send_button.setEnabled(false);
    	}
    }
    
    public void delay(int ms){
		try {
            Thread.currentThread();
			Thread.sleep(ms);
        } catch (InterruptedException e) {
            e.printStackTrace();
        } 
	 }	
    
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.gatt_services_characteristics);
        
        final Intent intent = getIntent();
        mDeviceName = intent.getStringExtra(EXTRAS_DEVICE_NAME);
        mDeviceAddress = intent.getStringExtra(EXTRAS_DEVICE_ADDRESS);

        // Sets up UI references.
        ((TextView) findViewById(R.id.device_address)).setText(mDeviceAddress);
     //   mGattServicesList = (ExpandableListView) findViewById(R.id.gatt_services_list);
     //   mGattServicesList.setOnChildClickListener(servicesListClickListner);
        mConnectionState = (TextView) findViewById(R.id.connection_state);
     //   mDataField = (TextView) findViewById(R.id.data_value);
        mBatData = (TextView) findViewById(R.id.bat_volt);
        mTempCData = (TextView) findViewById(R.id.temp_c);
        mTempCset = (TextView) findViewById(R.id.tc_set);
        mEnergyData = (TextView) findViewById(R.id.a_hours);
        mFreezerOn = (ImageView) findViewById(R.id.freezer_state);
        mInverterOn = (ImageView) findViewById(R.id.inverter_state);

        mFreezerOn.setImageDrawable(getResources().getDrawable(R.drawable.freezer_off));
        mInverterOn.setImageDrawable(getResources().getDrawable(R.drawable.inverter_off));

        switch_inverter=(ImageButton)findViewById(R.id.imageButton1);
        show_log=(ImageButton)findViewById(R.id.imageButton2);
        plus=(ImageButton)findViewById(R.id.imageButton3);
        minus=(ImageButton)findViewById(R.id.imageButton4);
        switch_inverter.setOnClickListener(listener);
        show_log.setOnClickListener(listener);
        plus.setOnClickListener(listener);
        minus.setOnClickListener(listener);
        
        switch_inverter.setImageDrawable(getResources().getDrawable(R.drawable.ac_off));
        minus.setImageDrawable(getResources().getDrawable(R.drawable.minus));
        
        switch_inverter.setEnabled(false);
        show_log.setEnabled(false);
        minus.setEnabled(false);
        switch_inverter.setEnabled(true);
        show_log.setEnabled(true);
        plus.setEnabled(true);
	    minus.setEnabled(true);



        GraphView graph = (GraphView) findViewById(R.id.graph);
        series = new LineGraphSeries<DataPoint>();
        // set second scale

// the y bounds are always manual for second scale
        graph.getSecondScale().setMinY(-25);
        graph.getSecondScale().setMaxY(25);
    //    graph.getGridLabelRenderer().setNumHorizontalLabels(10);
    //   graph.getGridLabelRenderer().setNumVerticalLabels(5);

        series.setThickness(4);
        series.setTitle("Battery V");
        graph.addSeries(series);

        series2 = new LineGraphSeries<DataPoint>();
        series2.setTitle("Freezer C");
        series2.setColor(Color.RED);
        series2.setThickness(4);
 //       series2.setBackgroundColor(Color.LTGRAY);
 //       series2.setDrawBackground(true);

        graph.getSecondScale().addSeries(series2);
        graph.getGridLabelRenderer().setVerticalLabelsSecondScaleColor(Color.RED);

        // activate horizontal scrolling
        graph.getViewport().setScrollable(true);
        // set manual X bounds
        graph.getViewport().setXAxisBoundsManual(true);
        graph.getViewport().setMinX(0);
        graph.getViewport().setMaxX(300);

// set manual Y bounds
        graph.getViewport().setYAxisBoundsManual(true);
        graph.getViewport().setMinY(10);
        graph.getViewport().setMaxY(15);

        graph.getViewport().setScalable(true);
        graph.getViewport().setScalableY(true);

        graph.getLegendRenderer().setVisible(true);
        graph.getLegendRenderer().setAlign(LegendRenderer.LegendAlign.BOTTOM);
        graph.getGridLabelRenderer().setNumHorizontalLabels(5);
        graph.getGridLabelRenderer().setNumVerticalLabels(6);







      //  send_button=(Button)findViewById(R.id.tx_button); //send data 1002
      //  send_button.setOnClickListener(listener);  //Set monitoring
        
      //  txd_txt=(EditText)findViewById(R.id.tx_text); //1002 data
      //  txd_txt.setText(txd_txt.getText());
        
//        id_btt=(Button)findViewById(R.id.id_button);//send data 1002
//        id_btt.setOnClickListener(listener); //Set monitoring 
//        //id_btt.setTag(0);
//        pass_btt=(Button)findViewById(R.id.pass_button);//send data 1002
//        pass_btt.setOnClickListener(listener); //Set monitoring 
//        name_btt=(Button)findViewById(R.id.name_button);//send data 1002
//        name_btt.setOnClickListener(listener); //Set monitoring 
        
        show_view(false);
        mHandler = new Handler();
        
        timer.schedule(task, 1000, 1000);  // 1s after the implementation of the task, after 1s again
        
        boolean sg;
        getActionBar().setTitle(mDeviceName);
        getActionBar().setDisplayHomeAsUpEnabled(true);
        Intent gattServiceIntent = new Intent(this, BluetoothLeService.class);
        sg = bindService(gattServiceIntent, mServiceConnection, BIND_AUTO_CREATE);
      //  getActionBar().setTitle( "="+BluetoothLeService );
      //  mDataField.setText("="+sg );
        updateConnectionState(R.string.connecting);
    }



 //   Handler handler =new Handler()  {
     private class MyHandler extends Handler {
        public void handleMessage(Message msg) {  
        	if (msg.what == 1) {  
                //tvShow.setText(Integer.toString(i++));  
            	//scanLeDevice(true);
            	if (mBluetoothLeService != null) {
            		if( connect_status_bit==false )
            		{
            			final boolean result = mBluetoothLeService.connect(mDeviceAddress);
            			Log.d(TAG, "Connect request result=" + result);
            		}
                }
            }  
            super.handleMessage(msg);  
        };
    }
    MyHandler handler=new MyHandler();
    TimerTask task = new TimerTask() {  
    	  
        @Override  
        public void run() {  
            // Things to do: send a message:  
            Message message = new Message();  
            message.what = 1;  
            handler.sendMessage(message);  
        }  
    }; 

    

    
    Button.OnClickListener listener = new Button.OnClickListener(){ //Create a listening object    
        public void onClick(View v){    
            //String strTmp="Click Button02";    
            //Ev1.setText(strTmp);   
        	switch( v.getId())
        	{
        	case R.id.imageButton1:
        	{

        			mBluetoothLeService.txxx( "31" );   // Keep Inverter Power On_Off


        	}
        	break;
        	case R.id.imageButton2:
            {

                    mBluetoothLeService.txxx( "35" );   // Display log graph


            }
            break;


                case R.id.imageButton3:
            {
                if (freezer_set < 35) {
                    freezer_set++;
                    mBluetoothLeService.txxx(Integer.toHexString(((freezer_set-7) & 0x03f) | 0x0c0));
            //        mTempCset.setText((freezer_set-25) + " C");
                }
            }
            break;

        	case R.id.imageButton4:
        	{

                if (freezer_set > 7) {

                    freezer_set--;
                    mBluetoothLeService.txxx( Integer.toHexString(((freezer_set-7) & 0x03f) | 0x0c0));
            //        mTempCset.setText((freezer_set-25) + " C");
                }


        		
        	}
        	break;
  /*      	case R.id.imageButton4 : //uuid1002 digital channel to send data
        		if( connect_status_bit )
      		  {
        			dme = "";
        			
            		String tx_string=txd_txt.getText().toString().trim();
            		mBluetoothLeService.txxx( tx_string );
     				 try {  
 			            Thread.currentThread();  
 			            Thread.sleep(100);  
 			        } catch (InterruptedException e) {  
 			            e.printStackTrace();  
 			        }
     				mBluetoothLeService.txxx( "55" );

      		  }else{
      			  //Toast.makeText(this, "Deleted Successfully!", Toast.LENGTH_LONG).show(); 
      			  Toast toast = Toast.makeText(DeviceControlActivity.this, "Device is not connected!", Toast.LENGTH_SHORT);
      			  toast.show(); 

        		break; */
//        	case R.id.id_button : //Used to read the device ID
//        	{
//        		String tx_string="aa5510eb3ced8e43e21e10a07f9607dd9709f1"; ;
//        		mBluetoothLeService.txxx(tx_string);
//        		Toast toast = Toast.makeText(DeviceControlActivity.this, "Used to read device ID!", Toast.LENGTH_SHORT); 
//    			toast.show(); 
//        		break;
//        	}
//        	case R.id.pass_button : //Used to change the password
//        	{
//        		Toast toast = Toast.makeText(DeviceControlActivity.this, "Equipment is not connected!", Toast.LENGTH_SHORT); 
//    			toast.show(); 
//        		break;
//        	}
//        	case R.id.name_button : //Used to change the device name
//        	{
//        		Toast toast = Toast.makeText(DeviceControlActivity.this, "Used to change the device name!", Toast.LENGTH_SHORT); 
//    			toast.show(); 
//        		break;
//        	}
        		default :
        			break;
        	}
        }    
  
    };  
    @Override
    protected void onResume() {
        super.onResume();
        registerReceiver(mGattUpdateReceiver, makeGattUpdateIntentFilter());
        if (mBluetoothLeService != null) {
        	
            final boolean result = mBluetoothLeService.connect(mDeviceAddress);
            Log.d(TAG, "Connect request result=" + result);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        unregisterReceiver(mGattUpdateReceiver);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unbindService(mServiceConnection);
        mBluetoothLeService = null;
        timer.cancel();
        timer=null;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.gatt_services, menu);
        if (mConnected) {
            menu.findItem(R.id.menu_connect).setVisible(false);
            menu.findItem(R.id.menu_disconnect).setVisible(true);
        } else {
            menu.findItem(R.id.menu_connect).setVisible(true);
            menu.findItem(R.id.menu_disconnect).setVisible(false);
        }
        return true;
    } 
 
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch(item.getItemId()) {
            case R.id.menu_connect:
                mBluetoothLeService.connect(mDeviceAddress);
                return true;
            case R.id.menu_disconnect:
                mBluetoothLeService.disconnect();
                return true;
            case android.R.id.home:
                onBackPressed();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void updateConnectionState(final int resourceId) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                mConnectionState.setText(resourceId);
            }
        });
    }


    boolean graphrec=false;

    private void displayData( byte[] data1 ) {

        if( data1==null) {
            return;

        }else if ((data1[0] == 0x2B)&&(!graphrec)){
            graphrec =true;
            datacount=0;
            datatoGraph(data1);
            return;

        }else if (graphrec){
            if (data1[data1.length-1]==-1) graphrec=false;
            datatoGraph(data1);
            return;

        } else if (data1[0] == 0x2A && data1[10]==0x23) {

            int v2 = (data1[3] << 8) | (data1[4] & 0x00ff);
            float v_bat = (float) (v2 / 51.2);
            int a2 = ((data1[5] & 0x00ff) << 8) | (data1[6] & 0x00ff);
            float ah_count = (float) a2 / 620;

            mBatData.setText(String.format("%.2f", v_bat) + " V");
            mTempCData.setText((data1[1] - 25) + " C");
            mTempCset.setText((data1[2] - 25) + " C");
            freezer_set = data1[2];
            mEnergyData.setText(String.format("%.1f", ah_count) + " Ah");

            if (data1[9] == 0x01) {
                keep_power = true;
                switch_inverter.setImageDrawable(getResources().getDrawable(R.drawable.ac_on));
            } else {
                keep_power = false;
                switch_inverter.setImageDrawable(getResources().getDrawable(R.drawable.ac_off));
            }

            if (data1[8] == 0x01) {
                freezer_on = true;
                mFreezerOn.setImageDrawable(getResources().getDrawable(R.drawable.freezer_on));
            } else {
                freezer_on = false;
                mFreezerOn.setImageDrawable(getResources().getDrawable(R.drawable.freezer_off));
            }
            if (data1[7] == 0x01) {

                mInverterOn.setImageDrawable(getResources().getDrawable(R.drawable.inverter_on));
            } else {
                mInverterOn.setImageDrawable(getResources().getDrawable(R.drawable.inverter_off));
            }


            return;

        }

    }

    // Demonstrates how to iterate through the supported GATT Services/Characteristics.
    // In this sample, we populate the data structure that is bound to the ExpandableListView
    // on the UI.
    private void displayGattServices(List<BluetoothGattService> gattServices) {
        if (gattServices == null) return;

        if( gattServices.size()>0&&mBluetoothLeService.get_connected_status( gattServices )>=4 )
        {
	        if( connect_status_bit )
			  {
	        	mConnected = true;
	        	
	            
	        	show_view( true );
				mBluetoothLeService.enable_JDY_ble(true,0); //Transparent uart service
				 try {  
			            Thread.currentThread();  
			            Thread.sleep(100);
			        } catch (InterruptedException e) {  
			            e.printStackTrace();  
			        }
	//			 mBluetoothLeService.txxx( "d9" ); //TX data
				 updateConnectionState(R.string.connected);
			  }else{
				  //Toast.makeText(this, "Deleted Successfully!", Toast.LENGTH_LONG).show(); 
				  //Toast toast = Toast.makeText(DeviceControlActivity.this, "Equipment is not connected!", Toast.LENGTH_SHORT); 
				  //toast.show(); 
			  }
        }
        
        
//        SimpleExpandableListAdapter gattServiceAdapter = new SimpleExpandableListAdapter(
//                this,
//                gattServiceData,
//                android.R.layout.simple_expandable_list_item_2,
//                new String[] {LIST_NAME, LIST_UUID},
//                new int[] { android.R.id.text1, android.R.id.text2 },
//                gattCharacteristicData,
//                android.R.layout.simple_expandable_list_item_2,
//                new String[] {LIST_NAME, LIST_UUID},
//                new int[] { android.R.id.text1, android.R.id.text2 }
//        );
//        
//        mGattServicesList.setAdapter(gattServiceAdapter);
        
    }
 
    private static IntentFilter makeGattUpdateIntentFilter() {
        final IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(BluetoothLeService.ACTION_GATT_CONNECTED);
        intentFilter.addAction(BluetoothLeService.ACTION_GATT_DISCONNECTED);
        intentFilter.addAction(BluetoothLeService.ACTION_GATT_SERVICES_DISCOVERED);
        intentFilter.addAction(BluetoothLeService.ACTION_DATA_AVAILABLE);
        intentFilter.addAction(BluetoothLeService.EXTRA_BYTES);
        return intentFilter;
    }

    byte[] graphdata =new byte[602];
    int datacount=0;


    private void datatoGraph(byte[] data2) {

        for ( int j=0 ; j < data2.length ; j++) {
            if (datacount < 602) graphdata[datacount++] = data2[j];
        }

        if ( data2[(data2.length)-1]== -1 ) {

            for (int i = 0; i < (datacount-2)/2 ; i++) {
                int v3 = (graphdata[2 * i + 1] & 0x00ff);
                series.appendData(new DataPoint(lastX, (float)v3 / 10), false, 300);
                series2.appendData(new DataPoint(lastX, graphdata[2 * i + 2]-25), false, 300);
                lastX++;

            }
            datacount=0;
            graphrec =false;

        }
    }


}

